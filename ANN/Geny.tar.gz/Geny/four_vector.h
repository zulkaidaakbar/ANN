#ifndef _FOUR_VECTOR_H
#define _FOUR_VECTOR_H

double product(double arr[], double arr2[]);
double tproduct(double arr[], double arr2[]);

#endif
