#ifndef _FORM_FACTOR_H
#define _FORM_FACTOR_H

double ffGE(double t);
double ffGM(double t);
double ffF2(double t);
double ffF1(double t);
double ffGA(double t);
double ffGP(double t);

#endif
